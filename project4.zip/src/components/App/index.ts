import { withTheme } from '../hocs';
import App from './App';

export default withTheme(App);
