import AuthNav from './AuthNav';

export default AuthNav;
