import Registration from './Registration';

export default Registration;
