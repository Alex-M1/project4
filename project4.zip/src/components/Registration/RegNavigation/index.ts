import RegNavigation from './RegNavigation';

export default RegNavigation;
