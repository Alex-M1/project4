import { withTheme, Theme } from './withTheme';

export {
  withTheme, Theme,
};
