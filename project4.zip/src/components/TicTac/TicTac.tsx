import React from 'react';

const TicTac: React.FC = () => {
  return (
    <div />
  );
};

export default TicTac;
