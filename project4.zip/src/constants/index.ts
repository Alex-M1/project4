import { colors } from './colors';

export {
  colors,
};
