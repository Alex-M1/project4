export const url = {
  authClient: '/',
  regClient: '/registration',
  server: 'ws://35.176.167.155:8089',
  registration: '/registration/reg',
  auth: '/authorization/auth',
  signUp: '/signup',
};
